# b4.run — Paper Relay

Open identity/index.html for the offline brand reference.
Read identity/guidelines.md for the full rules.
The URLs in assets.json refer to public files at https://b4.run.
Tight Shift files are archived alternatives.
