# B4.run Brand Assets

Official public brand assets for B4.run.

## Recommended usage

- Use `svg/b4-logo-horizontal-white.svg` on dark backgrounds.
- Use `svg/b4-logo-horizontal-black.svg` on light backgrounds.
- Use `svg/b4-icon-white.svg` or `svg/b4-icon-black.svg` for compact UI and logo grids.
- Use `social/b4-social-avatar-white-on-black-1024.png` for square social avatars.

Use the files as provided. Do not stretch, recolor, redraw, or use the B4.run marks in a way that implies endorsement.

For machine-readable metadata, see `assets.json`.
